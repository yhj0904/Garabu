function List() {
    return(

        <div><h4>List page</h4></div>
    )
    
}

export default List