function Details() {
    
    return(
        <div>
            <h4>Detail page 거래내역 페이지 달력으로 만들고 거래내역 적기</h4>
        </div>
    )
}

export default Details;